package com.example.empoweringthenationapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var btnLogIn = findViewById<Button>(R.id.btnLogIn)

        var edtEmail = findViewById<EditText>(R.id.edtEmail)

        var edtPassword = findViewById<EditText>(R.id.edtPassword)

        var tvSignUp = findViewById<TextView>(R.id.tvSignUp)

        var image = findViewById<ImageView>(R.id.imageView)
        image.setImageResource(R.drawable.img)

        btnLogIn.setOnClickListener {
            var Email = edtEmail.text.toString()
            var Password = edtPassword.text.toString()

            if (Email.isEmpty() || Password.isEmpty()) {
                // Empty email or password fields; show an error message.
                Toast.makeText(this, "Please fill in all required details.", Toast.LENGTH_SHORT).show()
            } else {
                var predefinedEmail = "user@example.com"
                var predefinedPassword = "password123"

                if (Email == predefinedEmail && Password == predefinedPassword) {
                    // Email and password match; navigate to the home page.
                    var intent = Intent(this, HomePage::class.java)
                    startActivity(intent)
                } else {
                    // Email and password do not match; show an error message.
                    Toast.makeText(
                        this,
                        "Login unsuccessful. Ensure details have been entered in correctly.",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }

        tvSignUp.setOnClickListener {
            var intent = Intent(this, SignUp::class.java)
            startActivity(intent)
        }
    }
}