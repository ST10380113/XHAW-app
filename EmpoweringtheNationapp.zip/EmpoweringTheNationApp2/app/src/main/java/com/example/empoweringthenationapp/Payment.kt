package com.example.empoweringthenationapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import models.Course

class Payment : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_payment)

        val selectedCourses = intent.getParcelableArrayListExtra<Course>("selectedCourses")

        val totalPrice = selectedCourses?.sumByDouble { it.price } ?: 0.0

        val discountPercentage = when (selectedCourses?.size ?: 0) {
            1 -> 0.00
            2 -> 0.05
            3 -> 0.1
            else -> 0.15
        }

        val discountAmount = totalPrice * discountPercentage

        val vat = 0.15 // 15% VAT
        val vatAmount = totalPrice * vat

        val finalTotal = totalPrice - discountAmount + vatAmount

        val tvDiscount = findViewById<TextView>(R.id.tvDiscount)
        tvDiscount.text = "Discount: ${String.format("%.2f%%", discountPercentage * 100)}"

        val tvTotal = findViewById<TextView>(R.id.tvTotal)
        tvTotal.text = "Total (with VAT and discount): $finalTotal"
    }
}